#!/usr/bin/env python3
"""Move the arm through a few small test poses.

It sends a FollowJointTrajectory ACTION goal, the same interface MoveIt 2 uses,
so once this works, MoveIt plugs into the same controller with no changes.

Run:   ros2 run mars_arm_test move_arm
       ros2 run mars_arm_test move_arm --ros-args -p scale:=0.5   (smaller moves)
"""
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from builtin_interfaces.msg import Duration
from control_msgs.action import FollowJointTrajectory
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

JOINTS = ["shoulder_joint", "elbow_joint", "wrist_joint"]

# Offsets in radians FROM the arm's current position, plus seconds to reach each.
# Kept small on purpose: there is no homing yet, so "0" is wherever the arm powered up.
POSES = [
    ([0.2, 0.0, 0.0], 3),   # shoulder only
    ([0.2, -0.2, 0.0], 6),  # + elbow
    ([0.2, -0.2, 0.5], 9),  # + wrist
    ([0.0, 0.0, 0.0], 13),  # back to start
]


class MoveArm(Node):
    def __init__(self):
        super().__init__("move_arm")
        self.declare_parameter("scale", 1.0)
        self.start = None
        self.create_subscription(JointState, "/joint_states", self.on_state, 10)
        self.client = ActionClient(self, FollowJointTrajectory,
                                   "/arm_controller/follow_joint_trajectory")

    def on_state(self, msg):
        if self.start is None and all(j in msg.name for j in JOINTS):
            self.start = [msg.position[msg.name.index(j)] for j in JOINTS]

    def run(self):
        self.get_logger().info("Waiting for /joint_states with all 3 joints...")
        while rclpy.ok() and self.start is None:
            rclpy.spin_once(self, timeout_sec=0.1)
        self.get_logger().info(f"Start position (rad): {[round(p, 3) for p in self.start]}")

        if not self.client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error("arm_controller action server not found. Is the launch running?")
            return

        scale = self.get_parameter("scale").value
        traj = JointTrajectory(joint_names=JOINTS)
        for offsets, t in POSES:
            traj.points.append(JointTrajectoryPoint(
                positions=[s + scale * o for s, o in zip(self.start, offsets)],
                time_from_start=Duration(sec=t)))

        goal = FollowJointTrajectory.Goal(trajectory=traj)
        self.get_logger().info("Sending trajectory...")
        send = self.client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, send)
        handle = send.result()
        if not handle.accepted:
            self.get_logger().error("Goal rejected (check joint names / limits).")
            return

        result = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result)
        code = result.result().result.error_code
        if code == 0:
            self.get_logger().info("Done: all poses reached.")
        else:
            self.get_logger().error(f"Trajectory failed, error_code={code} "
                                    f"({result.result().result.error_string})")


def main():
    rclpy.init()
    node = MoveArm()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
