# mars_arm_test

Minimal bring-up: ODrive shoulder + elbow and CubeMars AK45 wrist under **one** `joint_trajectory_controller`.

## Files
| File | What it does |
|---|---|
| `urdf/arm.urdf.xacro` | 3 joints (placeholder geometry) + two `<ros2_control>` hardware blocks, each swappable for a mock |
| `config/controllers.yaml` | `joint_state_broadcaster` + `arm_controller` (all 3 joints) |
| `launch/arm.launch.py` | one controller manager, robot_state_publisher, both spawners |
| `mars_arm_test/move_arm.py` | sends a small test trajectory via the `FollowJointTrajectory` action (same as MoveIt) |
| `../../start_test.sh` | brings up can0 at 1 Mbit/s, launches, cleans up on Ctrl+C |

## Build
```bash
cd ~/mars_ws
colcon build --symlink-install
source install/setup.bash
```

## Test ladder (do in order)
1. **No hardware:** `ros2 launch mars_arm_test arm.launch.py use_mock_odrive:=true use_mock_cubemars:=true`
2. **Wrist only:** `./start_test.sh use_mock_odrive:=true`
3. **ODrives only:** `./start_test.sh use_mock_cubemars:=true`
4. **Everything:** `./start_test.sh`

At each step, in a second terminal:
```bash
source ~/mars_ws/install/setup.bash
ros2 control list_controllers            # both "active"
ros2 control list_hardware_interfaces    # 3 joints [claimed]
ros2 topic echo /joint_states --once
ros2 run mars_arm_test move_arm --ros-args -p scale:=0.5
```

## Before step 3
- ODrives at 1 Mbit/s with encoder messages every 10 ms (`odrivetool`), node IDs 1 and 2.
- Nothing else commanding them (`odrive_can_node`, `can_ros2_node.py` not running).
- Each ODrive axis in closed-loop control (the plugin may do this on activate; if not, use `odrivetool`).
