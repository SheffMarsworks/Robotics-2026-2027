"""Bring up the whole arm under ONE controller manager.

Examples:
  ros2 launch mars_arm_test arm.launch.py                                   # real motors
  ros2 launch mars_arm_test arm.launch.py use_mock_odrive:=true use_mock_cubemars:=true   # no hardware
  ros2 launch mars_arm_test arm.launch.py use_mock_cubemars:=true           # ODrives only
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.substitutions import (Command, FindExecutable, LaunchConfiguration,
                                  PathJoinSubstitution)
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    pkg = FindPackageShare("mars_arm_test")

    args = [
        DeclareLaunchArgument("use_mock_odrive", default_value="false"),
        DeclareLaunchArgument("use_mock_cubemars", default_value="false"),
        DeclareLaunchArgument("can_interface", default_value="can0"),
    ]

    # Run xacro on the URDF, passing the launch arguments through
    robot_description = {
        "robot_description": ParameterValue(
            Command([
                FindExecutable(name="xacro"), " ",
                PathJoinSubstitution([pkg, "urdf", "arm.urdf.xacro"]),
                " use_mock_odrive:=", LaunchConfiguration("use_mock_odrive"),
                " use_mock_cubemars:=", LaunchConfiguration("use_mock_cubemars"),
                " can_interface:=", LaunchConfiguration("can_interface"),
            ]),
            value_type=str)
    }
    controllers = PathJoinSubstitution([pkg, "config", "controllers.yaml"])

    control_node = Node(
        package="controller_manager", executable="ros2_control_node",
        parameters=[robot_description, controllers], output="screen")

    robot_state_pub = Node(
        package="robot_state_publisher", executable="robot_state_publisher",
        parameters=[robot_description], output="screen")

    jsb_spawner = Node(
        package="controller_manager", executable="spawner",
        arguments=["joint_state_broadcaster", "-c", "/controller_manager"])

    arm_spawner = Node(
        package="controller_manager", executable="spawner",
        arguments=["arm_controller", "-c", "/controller_manager"])

    # Start the arm controller only after joint states are being published
    arm_after_jsb = RegisterEventHandler(
        OnProcessExit(target_action=jsb_spawner, on_exit=[arm_spawner]))

    return LaunchDescription(args + [control_node, robot_state_pub, jsb_spawner, arm_after_jsb])
