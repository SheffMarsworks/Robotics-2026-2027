#!/bin/bash
# Bring up can0 and launch the arm test. Extra args are passed to the launch file, e.g.
#   ./start_test.sh use_mock_cubemars:=true
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cleanup() { echo "[mars] bringing can0 down"; sudo ip link set can0 down 2>/dev/null || true; }
trap cleanup EXIT

sudo ip link set can0 down 2>/dev/null || true
sudo ip link set can0 type can bitrate 1000000
sudo ip link set can0 up
echo "[mars] can0 up at 1 Mbit/s"

source /opt/ros/humble/setup.bash
source "$SCRIPT_DIR/install/setup.bash"
ros2 launch mars_arm_test arm.launch.py "$@"
